Execute o comando "make" para compilar o programa.
Execute os programas com "./cliente <ip> <porta>" e "./servidor <porta> <delay>"