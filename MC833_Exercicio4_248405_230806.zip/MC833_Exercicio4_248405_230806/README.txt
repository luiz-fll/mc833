Execute o comando "make" para compilar o programa.
Execute os programas com "./cliente <ip> <porta>" e "./servidor <porta> <backlog> <delay>"
Execute o script bash com ./teste.sh <porta>
O arquivo "tcpdump.out" contém a saída do tcpdump executado conforme dito no relatório.